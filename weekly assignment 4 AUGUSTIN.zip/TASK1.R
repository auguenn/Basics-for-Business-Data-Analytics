# Task 1
# Load dataframe (1)
dat <- read_excel("C:/Users/augus/OneDrive/Documents/data analytics/Data for assignment Task 1/student performance data.xlsx")
dat<-data.frame(dat)

# Linear regression (2)
model <- lm(G3 ~  age +  traveltime + studytime + failures, data = dat)
model

# Return the predicted value from the model
dat$predictvalue <- predict(model)

# Create dataframe (3)
newstudents <- data.frame(
  age = c(20,16,9),
  traveltime = c(4,1,3),
  studytime = c(4,4,2),
  failures = c(0,3,4)
)
newstudents


# Predict the final grades (3)
predicted<-predict(model, newdata = newstudents)


# Make the dataframe (4)
students <- data.frame(ID=c(1,2,3),
                       age = c(20,16,9),
                       traveltime = c(4,1,3),
                       studytime = c(4,4,2),
                       failures = c(0,3,4),
                       finalgrade=predicted)
students
