#Task 2
#import the data (1)
dat <- read_excel("C:/Users/augus/OneDrive/Documents/data analytics/Data for assignent Task 2/Data for assignment Task 2 student performance data.xlsx")
dat<-data.frame(dat)
dat

#Saving variables into another dataframe (2)
dat2<- data.frame(G3=dat[,34], age=dat[,4], traveltime=dat[,14], studytime=dat[,15], failures=dat[,16])
dat2


#Creating a correlation plot and saving it as a pdf file (3)
pdf(file="figure 1.pdf")
corrplot(cor(dat2))
dev.off()


# Creating a ggplot and saving it as a pdf file (4)
pdf(file="figure 2.pdf")
ggplot(dat2, aes(x =age, y = G3)) +geom_point(color='red')
dev.off()

